#Theme for [SLiM](http://slim.berlios.de/) with [NixOS](http://nixos.org/) thematics.
![preview](https://github.com/jagajaga/nixos-slim-theme/raw/master/preview.png)
